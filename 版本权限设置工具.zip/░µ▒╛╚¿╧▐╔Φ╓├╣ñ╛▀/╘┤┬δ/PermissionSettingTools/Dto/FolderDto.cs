﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace PermissionSettingTools.Dto
{
    public class FolderDto : System.IComparable
    {
        private string name = "";
        private string parentName = "";
        private IList folders = new ArrayList();

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string ParentName
        {
            get { return parentName; }
            set { parentName = value; }
        }

        public IList Folders
        {
            get { return folders; }
            set { folders = value; }
        }

        public int CompareTo(object obj)
        {
            return this.name.CompareTo(((FolderDto)obj).Name);
        }
    }
}
