﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace PermissionSettingTools.Dto
{
    public class GroupDto
    {
        private string name = "";
        private string users = "";
        //private string parentName = "";
        //private IList users = new ArrayList();


        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Users
        {
            get { return users; }
            set { users = value; }
        }

        //public string ParentName
        //{
        //    get { return parentName; }
        //    set { parentName = value; }
        //}

        //public IList Users
        //{
        //    get { return users; }
        //    set { users = value; }
        //}
    }
}
