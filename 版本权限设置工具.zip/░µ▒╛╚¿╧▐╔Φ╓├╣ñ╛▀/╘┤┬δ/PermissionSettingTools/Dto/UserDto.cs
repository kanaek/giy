﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PermissionSettingTools.Dto
{
    public class UserDto
    {
        private string name = "";
        private string parentName = "";

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string ParentName
        {
            get { return parentName; }
            set { parentName = value; }
        }
    }
}
