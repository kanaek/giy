﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace PermissionSettingTools.Dto
{
    public class ProjectDto : System.IComparable
    {
        private string name = "";
        private IList groups = new ArrayList();
        private IList folders = new ArrayList();
        private IDictionary auths = new Hashtable();

        public IList Groups
        {
            get { return groups; }
            set { groups = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public IList Folders
        {
            get { return folders; }
            set { folders = value; }
        }

        public IDictionary Auths
        {
            get { return auths; }
            set { auths = value; }
        }

        public void clearAuth(string path)
        {
            this.auths.Remove(path);
        }

        public void addAuth(string path, string group, string right) {
            IDictionary auth = this.auths[path] as IDictionary;
            if (auth == null) {
                auth = new Hashtable();
                this.auths[path] = auth;
            }
            auth[group] = right;

            //string path2 = path;
            //int p = path2.LastIndexOf('/');
            //while (p >= 0)
            //{
            //    path2 = path2.Substring(0, p);
            //    if (path2.Length > 0)
            //    {
            //        auth = this.auths[path2] as IDictionary;
            //        if (auth == null)
            //        {
            //            auth = new Hashtable();
            //            auth[group] = "r";
            //            this.auths[path2] = auth;
            //        }

            //        p = path2.LastIndexOf("/");
            //    }
            //    else {
            //        break;
            //    }
            //}
        }

        public int CompareTo(object obj)
        {
            return this.name.CompareTo(((ProjectDto)obj).Name);
        }
    }
}
