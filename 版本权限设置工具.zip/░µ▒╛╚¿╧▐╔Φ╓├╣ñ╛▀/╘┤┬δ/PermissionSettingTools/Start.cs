﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using System.Xml;
using PermissionSettingTools.UI;
using PermissionSettingTools.Util;
//using PermissionSettingTools.Dto;
//using PermissionSettingTools.UI;

namespace PermissionSettingTools
{
    public static class Start
    {
        private static string logfilename = "config.xml";
        private static string logfilepath = string.Format(@"{0}\config\", System.Environment.CurrentDirectory);
        private static string xmlFileName = logfilepath + logfilename;
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            //RepoConfig.Projects.Add(projectDto);
            //RepoConfig.export();

            //bool flag = false;
            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //if (loadXml())
            //{
            //    Application.Run(new ManagementForm());
            //}

            //string file = @"C:\Users\terrytracy\Documents\Work\sirm\sirm_deploy\版本权限设置工具\源码\PermissionSettingTools\bin\Debug\a.ini";
            //Win32API.INIWriteValue(file, "name", "h", "a");
            // 初始化用户列表
            Application.Run(new MainWindow());
        }

        //private static void addFolder(FolderDto folderDto, XmlNode xmlNode)
        //{
        //    XmlNodeList childs = xmlNode.ChildNodes;
        //    foreach (XmlNode child in childs)
        //    {
        //        FolderDto folderDtoChild = new FolderDto();
        //        folderDtoChild.Name = child.Attributes["name"].Value;
        //        folderDtoChild.ParentName = folderDto.Name;
        //        folderDto.Folders.Add(folderDtoChild);

        //        addFolder(folderDtoChild, child);
        //    }
        //}

        //public static bool loadXml()
        //{
        //    bool ok = true;
        //    ConfigEdit edit = new ConfigEdit();
        //    XmlDocument doc = new XmlDocument();
        //    if (!File.Exists(xmlFileName))
        //    {
        //        if(MessageBox.Show("找不到config.xml文件，是否新建？", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question).ToString()=="Yes")
        //        {
        //            if(!edit.CreateXmlDocument("config", "1.0", "utf-8", null))
        //            {
        //                MessageBox.Show("新建失败！", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //                ok = false;
        //                return ok;
        //            }
        //        }
        //        else
        //        {
        //            ok = false;
        //            return ok;
        //        }
        //    }
        //    doc.Load(xmlFileName);
        //    XmlNode xmlRoot = doc.DocumentElement;
        //    XmlNodeList xmlNodeList = xmlRoot.ChildNodes;
        //    foreach (XmlNode xmlNode in xmlNodeList)
        //    {
        //        //解析group节点
        //        ProjectDto projectDto = new ProjectDto();
        //        projectDto.Name = xmlNode.Attributes["name"].Value;
        //        XmlNodeList groupLists = edit.GetXmlNodeListByXpath("/config/project/groups");
        //        foreach (XmlNode groupList in groupLists)
        //        {
        //            if (groupList.ParentNode.Attributes["name"].Value == projectDto.Name)
        //            {
        //                XmlNodeList groups = groupList.ChildNodes;
        //                foreach (XmlNode group in groups)
        //                {
        //                    GroupDto groupDto = new GroupDto();
        //                    groupDto.Name = group.Attributes["name"].Value;
        //                    groupDto.ParentName = projectDto.Name;

        //                    XmlNodeList users = group.ChildNodes;
        //                    foreach (XmlNode user in users)
        //                    {
        //                        UserDto userDto = new UserDto();
        //                        userDto.Name = user.Attributes["name"].Value;
        //                        userDto.ParentName = groupDto.Name;

        //                        groupDto.Users.Add(userDto);
        //                    }
        //                    projectDto.Groups.Add(groupDto);
        //                }
        //            }
        //        }

        //        //解析structure节点
        //        XmlNodeList structures = edit.GetXmlNodeListByXpath("/config/project/structure");
        //        foreach (XmlNode structure in structures)
        //        {
        //            if (structure.ParentNode.Attributes["name"].Value == projectDto.Name)
        //            {
        //                XmlNodeList folders = structure.ChildNodes;
        //                foreach (XmlNode folder in folders)
        //                {
        //                    FolderDto folderDto = new FolderDto();
        //                    folderDto.Name = folder.Attributes["name"].Value;
        //                    folderDto.ParentName = projectDto.Name;
        //                    //递归调用addFolder方法
        //                    addFolder(folderDto, folder);

        //                    projectDto.Folders.Add(folderDto);
        //                }
        //            }
        //        }

        //        //解析authz节点
        //        XmlNodeList authzs = edit.GetXmlNodeListByXpath("/config/project/authz");
        //        foreach (XmlNode authz in authzs)
        //        {
        //            if (authz.ParentNode.Attributes["name"].Value == projectDto.Name)
        //            {
        //                XmlNodeList auths = authz.ChildNodes;
        //                foreach (XmlNode auth in auths)
        //                {
        //                    AuthDto authDto = new AuthDto();
        //                    authDto.Path = auth.Attributes["path"].Value;
        //                    XmlNodeList items = auth.ChildNodes;
        //                    foreach (XmlNode item in items)
        //                    {
        //                        ItemDto itemDto = new ItemDto();
        //                        itemDto.GroupName = item.Attributes["group"].Value;
        //                        itemDto.Right = item.Attributes["right"].Value;

        //                        authDto.Items.Add(itemDto);
        //                    }
        //                    projectDto.Auths.Add(authDto);
        //                }
        //            }
        //        }

        //        //保存到内存
        //        ManagementForm.Projects.Add(projectDto);
        //        GroupsPanel.Projects.Add(projectDto);
        //        SetAuthzPanel.Projects.Add(projectDto);
        //        AuthFilePanel.Projects.Add(projectDto);
        //        AuthzDetailsForm.Projects.Add(projectDto);
        //        AddGroupForm.Projects.Add(projectDto);
        //        RepoConfig.Projects.Add(projectDto);
        //    }
        //    return ok;
        //}
    }
}
