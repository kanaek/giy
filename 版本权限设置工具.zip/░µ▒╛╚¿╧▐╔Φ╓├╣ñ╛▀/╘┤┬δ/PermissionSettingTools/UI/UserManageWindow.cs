﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using PermissionSettingTools.Dto;
using PermissionSettingTools.Util;

namespace PermissionSettingTools.UI
{
    public partial class UserManageWindow : Form
    {
        private string projectName = null;
        public string ProjectName {
            set {
                this.projectName = value;
            }

            get {
                return this.projectName;
            }
        }

        public UserManageWindow()
        {
            InitializeComponent();
            this.dgvUsers.CellValueChanged += new DataGridViewCellEventHandler(dgvUsers_CellValueChanged);
            this.dgvUsers.CellContentClick += new DataGridViewCellEventHandler(dgvUsers_CellContentClick);
            this.tsbSave.Click += new EventHandler(tsbSave_Click);
            this.tsbInit.Click += new EventHandler(tsbInit_Click);
            this.Load += new EventHandler(UserManageWindow_Load);
        }

        void UserManageWindow_Load(object sender, EventArgs e)
        {
            ProjectDto project = ProjectUtil.getProjectDto(this.ProjectName);
            foreach(GroupDto groupdto in project.Groups){
                object[] rows = new object[] {groupdto.Name, groupdto.Users};
                this.dgvUsers.Rows.Add(rows);
            }
        }

        void tsbInit_Click(object sender, EventArgs e)
        {
            int rc = this.dgvUsers.Rows.Count;
            if (rc > 0){
                DialogResult dr = MessageBox.Show("初始化操作会覆盖目前的设置，是否继续？", "确认", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (dr == DialogResult.OK)
                {
                    this.dgvUsers.Rows.Clear();
                }
            }
            this.dgvUsers.Rows.Add(new object[] { "deptmanager" }); // 部门经理
            this.dgvUsers.Rows.Add(new object[] { "devleader" }); // 开发主管
            this.dgvUsers.Rows.Add(new object[] { "prjmanager" }); // 项目经理
            this.dgvUsers.Rows.Add(new object[] { "developer" }); // 开发人员
            this.dgvUsers.Rows.Add(new object[] { "testor" });// 测试人员
            this.dgvUsers.Rows.Add(new object[] { "deployer" }); // 实施人员
            this.dgvUsers.Rows.Add(new object[] { "inspector" }); // 项目督察

            this.tsbSave.Enabled = true;
        }

        void tsbSave_Click(object sender, EventArgs e)
        {
            this.btnDummy.Focus();
            IList groups = new ArrayList();
            foreach (DataGridViewRow dgvr in this.dgvUsers.Rows)
            {
                DataGridViewCell dgvc = dgvr.Cells[0];
                string groupname = Convert.ToString(dgvc.Value).Trim();
                if (groupname.Length > 0)
                {
                    GroupDto groupdto = new GroupDto();
                    groupdto.Name = groupname;
                    groupdto.Users = Convert.ToString(dgvr.Cells[1].Value);
                    groups.Add(groupdto);
                }
            }

            ProjectDto project = ProjectUtil.getProjectDto(this.projectName);
            project.Groups = groups;

            ProjectUtil.saveProjectAuthz(this.projectName);
            MessageBox.Show("保存成功");

            this.tsbSave.Enabled = false;
        }

        void dgvUsers_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            this.tsbSave.Enabled = true;
        }

        private void dgvUsers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colname = this.dgvUsers.Columns[e.ColumnIndex].Name;
            if (colname.Equals("colDelete")) {
                this.dgvUsers.Rows.RemoveAt(e.RowIndex);
                this.tsbSave.Enabled = true;
            }
        }
    }
}
