﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace PermissionSettingTools.UI
{
    public class DataGridViewComboEditBoxColumn : DataGridViewComboBoxColumn
    {
        public DataGridViewComboEditBoxColumn()
        {
            DataGridViewComboEditBoxCell obj = new DataGridViewComboEditBoxCell();
            this.CellTemplate = obj;
        }
    }
}
