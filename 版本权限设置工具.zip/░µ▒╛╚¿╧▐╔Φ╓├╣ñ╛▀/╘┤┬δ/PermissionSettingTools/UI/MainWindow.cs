﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PermissionSettingTools.Dto;
using PermissionSettingTools.Util;
using System.IO;
using System.Collections;

namespace PermissionSettingTools.UI
{
    public partial class MainWindow : Form
    {
        private string projectName = null;
        private string folderpath = null;
        private bool labelEdited = false;

        public MainWindow()
        {
            InitializeComponent();
            this.dgvRight.CellContentClick += new DataGridViewCellEventHandler(dgvRight_CellContentClick);
            this.dgvRight.CellValueChanged += new DataGridViewCellEventHandler(dgvRight_CellValueChanged);
            this.tvProject.NodeMouseDoubleClick += new TreeNodeMouseClickEventHandler(tvProject_NodeMouseDoubleClick);
            this.tvProject.AfterSelect += new TreeViewEventHandler(tvProject_AfterSelect);
            this.tvProject.AfterLabelEdit += new NodeLabelEditEventHandler(tvProject_AfterLabelEdit);
            this.Load += new EventHandler(MainWindow_Load);
        }

        void tvProject_AfterLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            labelEdited = true;
            this.tvProject.BeginInvoke(new AfterTreeLabelEditDelegate(afterTreeLabelEdit));
        }

        private delegate void AfterTreeLabelEditDelegate();
        void afterTreeLabelEdit()
        {
            TreeNode e = tvProject.SelectedNode;
            this.tvProject_AfterSelect(null, new TreeViewEventArgs(e));
        }

        void MainWindow_Load(object sender, EventArgs e)
        {
            // 加载项目
            DirectoryInfo dir = new DirectoryInfo(System.Environment.CurrentDirectory);
            FileInfo[] files = dir.GetFiles("*_structure.txt");
            if (files != null) {
                foreach (FileInfo fileInfo in files) {
                    int i = fileInfo.Name.LastIndexOf("_structure");
                    string name = fileInfo.Name.Substring(0, i);
                    ProjectUtil.loadProjectStructure(name);
                }
            }

            // 加载授权文件
            files = dir.GetFiles("*_authz.ini");
            if (files != null)
            {
                foreach (FileInfo fileInfo in files)
                {
                    int i = fileInfo.Name.LastIndexOf("_authz");
                    string name = fileInfo.Name.Substring(0, i);
                    ProjectUtil.loadProjectAuthz(name);
                }
            }

            TreeNode rootNode = this.tvProject.Nodes[0];
            // 初始化属性结构
            IList projectDtos = ProjectUtil.getProjectDtos();
            foreach (ProjectDto projectDto in projectDtos) {
                TreeNode projectNode = createNode(projectDto.Name, "project");
                projectNode.NodeFont = new Font(this.tvProject.Font, FontStyle.Bold); 

                addProjectToTree(projectNode, projectDto.Folders);
                rootNode.Nodes.Add(projectNode);

                projectNode.Expand();
            }
            rootNode.Expand();
        }

        private void addProjectToTree(TreeNode parentNode, IList folders) {
            foreach (FolderDto folder in folders) {
                TreeNode node = createNode(folder.Name, "folder");
                addProjectToTree(node, folder.Folders);
                parentNode.Nodes.Add(node);
            }
        }

        void tvProject_AfterSelect(object sender, TreeViewEventArgs e)
        {
            string prevproject = this.projectName;
            string prevfolderpath = this.folderpath;

            this.projectName = null;
            // 搜索所在项目
            lblProjectPath.Text = e.Node.FullPath;
            TreeNode node = findProjectNode();
            if (node != null)
            {
                this.projectName = node.Text;
            }

            bool projectchanged = false;
            // 加载用户名
            if (this.projectName != null) {
                ProjectDto projectDto = ProjectUtil.getProjectDto(this.projectName);
                projectchanged = (prevproject == null && this.projectName != null) ||
                                (this.projectName != null && !this.projectName.Equals(prevproject));
                if (projectchanged)
                {
                    DataGridViewComboBoxColumn column = dgvRight.Columns[0] as DataGridViewComboBoxColumn;
                    column.Items.Clear();
                    foreach (GroupDto group in projectDto.Groups)
                    {
                        column.Items.Add(group.Name);
                    }
                }

                // 刷新权限表格
                dgvRight.Rows.Clear();
                if (this.folderpath != null)
                {
                    //ProjectDto projectDto = ProjectUtil.getProjectDto(this.projectName);
                    IDictionary folderauth = projectDto.Auths[this.folderpath] as IDictionary;
                    if (folderauth != null)
                    {
                        ArrayList auths = new ArrayList(folderauth.Keys);
                        auths.Sort();
                        foreach (string group in auths)
                        {
                            dgvRight.Rows.Add(group, folderauth[group]);
                        }
                    }
                }

                if (labelEdited) {
                    labelEdited = false;
                    // 同步在项目模型中的结构
                    projectDto.Folders = projectNodeToFolders();
                }
            }
        }

        private TreeNode findProjectNode() {
            StringBuilder sb = new StringBuilder();

            TreeNode result = null;
            TreeNode node = this.tvProject.SelectedNode;
            while (node.Parent != null)
            {
                if (node.Tag.Equals("project"))
                {
                    result = node;
                    break;
                }
                else {
                    sb.Insert(0, "/" + node.Text);
                }
                node = node.Parent;
            }
            if (result != null) {
                this.folderpath = sb.Length == 0 ? "/" : sb.ToString();
            }
            return result;
        }

        void tvProject_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            e.Node.BeginEdit();
        }

        void dgvRight_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            tsbSave.Enabled = true;
        }

        void dgvRight_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colname = this.dgvRight.Columns[e.ColumnIndex].Name;
            if (colname.Equals("colDelete"))
            {
                this.dgvRight.Rows.RemoveAt(e.RowIndex);
                this.tsbSave.Enabled = true;
            }
        }

        private void toolStripButton8_Click(object sender, EventArgs e){
            if (this.projectName == null || this.projectName.Length == 0) {
                MessageBox.Show("请选择项目!");
                return;
            }
            UserManageWindow window = new UserManageWindow();
            window.ProjectName = this.projectName;
            window.Show();
        }

        private void tsbRefresh_Click(object sender, EventArgs e)
        {
            btnDummy.Focus();

            ProjectDto project = ProjectUtil.getProjectDto(this.projectName);
            DataGridViewComboBoxColumn colgroup = (DataGridViewComboBoxColumn)this.dgvRight.Columns[0];
            colgroup.Items.Clear();
            foreach (GroupDto groupdto in project.Groups)
            {
                colgroup.Items.Add(groupdto.Name);
            }
        }

        private void tsbNewFolder_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = this.tvProject.SelectedNode;
            bool selected = selectedNode != null;
            if (!selected){
                MessageBox.Show("请选择上级节点!");
                return;
            }

            bool created = false;
            string tag = selectedNode.Tag as string;
            if ("projects".Equals(tag))
            {
                string input = Prompt.ShowDialog("请输入项目代码(例如：xn_jj_pazc_km2)", "输入").Trim();
                if (input != null && input.Trim().Length > 0) {
                    TreeNode projectNode = new TreeNode();
                    projectNode.Text = input;
                    projectNode.Tag = "project";
                    projectNode.NodeFont = new Font(this.tvProject.Font, FontStyle.Bold);
                    selectedNode.Nodes.Add(projectNode);
                    this.tvProject.SelectedNode = projectNode;

                    created = true;
                }
            }
            else{
                string input = Prompt.ShowDialog("请输入目录名称", "输入").Trim();
                if (input != null && input.Trim().Length > 0) {
                    TreeNode projectNode = new TreeNode();
                    projectNode.Text = input;
                    projectNode.Tag = "folder";
                    selectedNode.Nodes.Add(projectNode);

                    created = true;
                }
            }
            selectedNode.Expand();

            // 同步在项目模型中的结构
            if (created) {
                ProjectDto projectDto = ProjectUtil.getProjectDto(this.projectName);
                projectDto.Folders = projectNodeToFolders();
            }
        }

        private void tsbInitProject_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = this.tvProject.SelectedNode;
            bool selected = selectedNode != null && selectedNode.Tag.Equals("project");
            if (!selected){
                MessageBox.Show("请选择需要初始化的项目!");
                return;
            }

            ProjectDto projectDto = ProjectUtil.getProjectDto(this.projectName);
            if (selectedNode.Nodes.Count > 0)
            {
                DialogResult dr = MessageBox.Show("初始化操作会覆盖目前的项目结构，是否继续？", "确认", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (dr == DialogResult.OK)
                {
                    selectedNode.Nodes.Clear();
                    projectDto.Auths.Clear();
                }
            }

            projectDto.addAuth("/", "deptmanager", "rw");
            projectDto.addAuth("/", "devleader", "rw");
            projectDto.addAuth("/", "prjmanager", "rw");
            selectedNode.Nodes.Add(initBranchesNode(projectDto));
            selectedNode.Nodes.Add(initTagsNode(projectDto));
            selectedNode.Nodes.Add(initTrunkNode(projectDto));

            selectedNode.Expand();
            
            // 同步在项目模型中的结构
            projectDto = ProjectUtil.getProjectDto(this.projectName);
            projectDto.Folders = projectNodeToFolders();
        }

        private IList projectNodeToFolders() {
            IList result = new ArrayList();
            TreeNode projectNode = this.findProjectNode();
            if (projectNode != null) {
                result = projectNodeToFolders(projectNode, projectNode.Text);
            }
            return result;
        }

        private IList projectNodeToFolders(TreeNode parentNode, string parentText) {
            IList result = new ArrayList();
            if (parentNode != null) {
                foreach (TreeNode node in parentNode.Nodes) {
                    FolderDto folder = new FolderDto();
                    folder.Name = node.Text;
                    folder.ParentName = parentText;
                    folder.Folders = projectNodeToFolders(node, node.Text);
                    result.Add(folder);
                }
            }

            return result;
        }

        private static TreeNode initBranchesNode(ProjectDto projectDto)
        {
            projectDto.addAuth("/branches", "developer", "rw");
            projectDto.addAuth("/branches", "deployer", "rw");
            return createNode("branches", "folder");
        }

        private static TreeNode initTagsNode(ProjectDto projectDto)
        {
            projectDto.addAuth("/tags", "deployer", "rw");
            return createNode("tags", "folder");
        }

        private static TreeNode initTrunkNode(ProjectDto projectDto)
        {
            projectDto.addAuth("/trunk/doc", "inspector", "rw");

            projectDto.addAuth("/trunk/doc/00.项目计划", "testor", "r");
            projectDto.addAuth("/trunk/doc/01.用户需求", "testor", "r");
            projectDto.addAuth("/trunk/doc/02.需求分析", "testor", "r");

            projectDto.addAuth("/trunk/doc/03.模板", "developer", "rw");
            projectDto.addAuth("/trunk/doc/03.模板", "deployer", "r");
            projectDto.addAuth("/trunk/doc/03.模板", "testor", "r");

            projectDto.addAuth("/trunk/doc/03.数据导入", "developer", "rw");
            projectDto.addAuth("/trunk/doc/03.数据导入", "deployer", "r");
            projectDto.addAuth("/trunk/doc/03.数据导入", "testor", "r");

            projectDto.addAuth("/trunk/doc/04.设计", "developer", "rw");
            projectDto.addAuth("/trunk/doc/05.质量", "testor", "rw");

            projectDto.addAuth("/trunk/doc/06.发布", "developer", "rw");
            projectDto.addAuth("/trunk/doc/06.发布", "deployer", "r");

            projectDto.addAuth("/trunk/doc/07.部署", "deployer", "rw");

            projectDto.addAuth("/trunk/src", "developer", "rw");
            projectDto.addAuth("/trunk/src", "deployer", "rw");

            projectDto.addAuth("/trunk/lib", "developer", "rw");
            projectDto.addAuth("/trunk/lib", "deployer", "rw");

            projectDto.addAuth("/trunk/dll", "developer", "rw");
            projectDto.addAuth("/trunk/dll", "deployer", "rw");

            TreeNode result = createNode("trunk", "folder");
            TreeNode docNode = createNode("doc", "folder");
            TreeNode srcNode = createNode("src", "folder");
            TreeNode libNode = createNode("lib", "folder");
            TreeNode dllNode = createNode("dll", "folder");
            result.Nodes.Add(docNode);
            result.Nodes.Add(srcNode);
            result.Nodes.Add(libNode);
            result.Nodes.Add(dllNode);
            // 初始化doc
            docNode.Nodes.Add(createNode("00.项目计划", "folder"));
            docNode.Nodes.Add(createNode("01.用户需求", "folder"));
            docNode.Nodes.Add(createNode("02.需求分析", "folder"));
            docNode.Nodes.Add(createNode("03.模板", "folder"));
            docNode.Nodes.Add(createNode("03.数据导入", "folder"));
            docNode.Nodes.Add(createNode("04.设计", "folder"));
            docNode.Nodes.Add(createNode("05.质量", "folder"));
            docNode.Nodes.Add(createNode("06.发布", "folder"));
            docNode.Nodes.Add(createNode("07.部署", "folder"));
            docNode.Nodes.Add(createNode("08.会议纪要", "folder"));
            docNode.Nodes.Add(createNode("09.项目周报", "folder"));
            docNode.Nodes.Add(createNode("10.验收", "folder"));

            return result;
        }

        private static TreeNode createNode(string text, string tag) {
            TreeNode result = new TreeNode(text);
            result.Tag = tag;
            return result;
        }

        private void tsbDelFolder_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = this.tvProject.SelectedNode;
            bool selected = selectedNode != null;
            if (!selected)
            {
                MessageBox.Show("请选择需要删除的目录!");
                return;
            }

            DialogResult dr = MessageBox.Show("确认删除？", "确认", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (dr == DialogResult.OK)
            {
                string _projectname = this.projectName;
                TreeNode parentNode = selectedNode.Parent;
                selectedNode.Remove();
                this.tvProject.SelectedNode = parentNode;

                // 同步在项目模型中的结构
                if (this.projectName != null && this.projectName.Length > 0)
                {
                    ProjectDto projectDto = ProjectUtil.getProjectDto(this.projectName);
                    projectDto.Folders = projectNodeToFolders();
                }
                else if (_projectname != null && _projectname.Length > 0){
                    ProjectUtil.deleteProjectDto(_projectname);
                }
                
            }
        }

        private void tsbSaveProject_Click(object sender, EventArgs e)
        {
            if (this.projectName == null || this.projectName.Length == 0)
            {
                MessageBox.Show("请选择项目!");
                return;
            }
            ProjectUtil.saveProjectStructure(this.projectName);
            ProjectUtil.saveProjectAuthz(this.projectName);

            MessageBox.Show("保存成功!");
        }

        private void tsbSave_Click(object sender, EventArgs e)
        {
            if (this.projectName == null || this.projectName.Length == 0)
            {
                MessageBox.Show("请选择项目!");
                return;
            }
            btnDummy.Focus();

            ProjectDto project = ProjectUtil.getProjectDto(this.projectName);
            project.clearAuth(this.folderpath);

            foreach (DataGridViewRow dgvr in this.dgvRight.Rows) {
                string groupname = dgvr.Cells[0].Value as string;
                if (groupname != null){
                    groupname = groupname.Trim();
                    string rightname = (dgvr.Cells[1].Value as string).Trim();
                    if (groupname.Length > 0 && rightname.Length > 0) {
                        project.addAuth(this.folderpath, groupname, rightname);
                    }
                }
            }
            MessageBox.Show("保存成功!");
        }
    }
}
