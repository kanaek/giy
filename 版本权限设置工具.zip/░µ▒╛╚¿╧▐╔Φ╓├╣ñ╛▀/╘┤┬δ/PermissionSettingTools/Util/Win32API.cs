﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.IO;
using System.Collections;

namespace PermissionSettingTools.Util
{
    public class Win32API
    {
        /// <summary>
        /// 读取INI文件中指定INI文件中的所有节点名称(Section)
        /// </summary>
        /// <param name="iniFile">Ini文件</param>
        /// <returns>所有节点,没有内容返回string[0]</returns>
        public static string[] INIGetAllSectionNames(string iniFile)
        {
            string[] sections = new string[0];      //返回值
            ArrayList list = new ArrayList();

            StreamReader sr = new StreamReader(iniFile);
            string line = null;
            while( (line = sr.ReadLine()) != null){
                if (line.StartsWith("[") && line.EndsWith("]")) {
                    list.Add(line.Substring(1, line.Length-2).Trim());
                }
            }
            sr.Close();

            sections = new string[list.Count];
            for(int i =0; i < list.Count; i++){
                sections[i] = (string)list[i];
            }

            return sections;
        }

        /// <summary>
        /// 获取INI文件中指定节点(Section)中的所有条目(key=value形式)
        /// </summary>
        /// <param name="iniFile">Ini文件</param>
        /// <param name="section">节点名称</param>
        /// <returns>指定节点中的所有项目,没有内容返回string[0]</returns>
        public static string[] INIGetAllItems(string iniFile, string section)
        {
            ArrayList list = new ArrayList();

            string[] items = new string[0];      //返回值
            StreamReader sr = new StreamReader(iniFile);
            string line = null;

            bool isok = false;
            while ((line = sr.ReadLine()) != null)
            {
                if (line.StartsWith("[") && line.EndsWith("]"))
                {
                    string name = line.Substring(1, line.Length - 2).Trim();
                    if (string.Compare(name, section, true) == 0)
                    {
                        isok = true;
                    }
                    else{
                        isok = false;
                    }
                }
                else {
                    if (isok) {
                        if (line.Trim().Length > 0 && line.IndexOf('=') > 0)
                        {
                            list.Add(line.Trim());
                        }
                    }
                }
            }

            sr.Close();
            
            items = new string[list.Count];
            for (int i = 0; i < list.Count; i++)
            {
                items[i] = (string)list[i];
            }
            return items;
        }
    }
}
