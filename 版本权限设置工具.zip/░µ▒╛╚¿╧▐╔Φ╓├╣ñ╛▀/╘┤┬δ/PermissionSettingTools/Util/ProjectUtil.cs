﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Collections;
using PermissionSettingTools.Dto;
using System.Windows.Forms;

namespace PermissionSettingTools.Util
{
    class ProjectUtil
    {
        private static IDictionary projects = new Hashtable();

        public static ProjectDto getProjectDto(string name) { 
            ProjectDto result = projects[name] as ProjectDto;
            if (result == null) {
                result = new ProjectDto();
                result.Name = name;
                projects[name] = result;
            }
            return result;
        }

        public static void deleteProjectDto(string name)
        {
            ProjectDto result = projects[name] as ProjectDto;
            if (result != null)
            {
                projects.Remove(name);
            }
        }

        public static IList getProjectDtos() {
            ArrayList result = new ArrayList();
            result.AddRange(projects.Values);
            result.Sort();

            return result;
        }


        /// <summary>
        /// 加载项目
        /// </summary>
        /// <param name="name"></param>
        public static void loadProjectStructure(string name)
        {
            string filepath = string.Format(@"{0}\{1}_structure.txt", System.Environment.CurrentDirectory, name);
            FileInfo structurefile = new FileInfo(filepath);
            if (structurefile.Exists) {
                IDictionary rootFolderMap = new Hashtable();
                IDictionary folderMap = rootFolderMap;
                string line = null;
                StreamReader reader = new StreamReader(structurefile.FullName);
                while ((line = reader.ReadLine()) != null) {
                    string[] pathItems = line.Split('/');
                    foreach (string str in pathItems) {
                        string pathItem = str.Trim();
                        if (pathItem.Length > 0){
                            IDictionary thisMap = folderMap[pathItem] as IDictionary;
                            if (thisMap == null) {
                                thisMap = new Hashtable();
                                folderMap[pathItem] = thisMap;
                            }
                            folderMap = thisMap;
                        }
                    }
                    folderMap = rootFolderMap;
                }
                reader.Close();


                ProjectDto project = getProjectDto(name);
                project.Folders = toFolders(rootFolderMap, "");
            }
        }

        private static IList toFolders(IDictionary folderMap, string parent) {
            ArrayList result = new ArrayList();
            if (folderMap != null){
                foreach(object foldername in folderMap.Keys){
                    FolderDto folder = new FolderDto();
                    folder.Name = foldername as string;
                    folder.ParentName = parent;
                    folder.Folders = toFolders(folderMap[foldername] as IDictionary, folder.Name);
                    result.Add(folder);
                }
            }
            result.Sort();
            
            return result;
        }

        /// <summary>
        /// 加载项目
        /// </summary>
        /// <param name="name"></param>
        public static void loadProjectAuthz(string name)
        {
            string filepath = string.Format(@"{0}\{1}_authz.ini", System.Environment.CurrentDirectory, name);
            FileInfo authzfile = new FileInfo(filepath);
            if (authzfile.Exists)
            {
                ProjectDto project = getProjectDto(name);
                IList groups = new ArrayList();

                // 加载用户
                string[] groupItems = Win32API.INIGetAllItems(filepath, "groups");
                foreach (string str in groupItems) {
                    int p = str.IndexOf('=');
                    GroupDto groupDto = new GroupDto();
                    groupDto.Name = str.Substring(0, p).Trim();
                    groupDto.Users = (p + 1) >= str.Length ? "" : str.Substring(p+1).Trim();
                    groups.Add(groupDto);
                }
                project.Groups = groups;

                // 加载授权
                string[] sections = Win32API.INIGetAllSectionNames(filepath);
                if (sections != null && sections.Length > 0) {
                    foreach (string section in sections) {
                        if (!section.Equals("groups")) {
                            int p = section.IndexOf(':');
                            string path = section.Substring(p+1);
                            string[] items = Win32API.INIGetAllItems(filepath, section);
                            if (items != null && items.Length > 0) {
                                foreach (string item in items) {
                                    p = item.IndexOf('=');
                                    string g = item.Substring(1, p-1).Trim();
                                    string r = (p + 1) >= item.Length ? "" : item.Substring(p + 1).Trim();
                                    if (r.Length > 0) {
                                    //    if (!"/".Equals(path) || "rw".Equals(r)) {
                                            project.addAuth(path, g, r);
                                    //    }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 保存工程结构
        /// </summary>
        /// <param name="name">工程名称</param>
        public static void saveProjectStructure(string name) {
            ProjectDto project = getProjectDto(name);

            string filepath = string.Format(@"{0}\{1}_structure.txt", System.Environment.CurrentDirectory, name);
            FileInfo structurefile = new FileInfo(filepath);
            StreamWriter sw = new StreamWriter(filepath, false);
            foreach (FolderDto dto in project.Folders) {
                saveProjectStructure(sw, dto, "");
            }

            sw.Close();
        }

        private static void saveProjectStructure(StreamWriter sw, FolderDto folder, string parentpath)
        {
            string path = parentpath + "/" + folder.Name;
            sw.WriteLine(path);
            foreach(FolderDto dto in folder.Folders){
                saveProjectStructure(sw, dto, path);
            }
        }

        /// <summary>
        /// 保存工程授权
        /// </summary>
        /// <param name="name">工程名称</param>
        public static void saveProjectAuthz(string name)
        {
            ProjectDto project = getProjectDto(name);

            string filepath = string.Format(@"{0}\{1}_authz.ini", System.Environment.CurrentDirectory, name);
            FileInfo structurefile = new FileInfo(filepath);
            StreamWriter sw = new StreamWriter(filepath, false);
            sw.WriteLine("[groups]");
            foreach(GroupDto groupdto in project.Groups){
                sw.WriteLine(groupdto.Name + "=" + groupdto.Users);
            }
            sw.WriteLine();

            // 输出权限
            IDictionary authMap = project.Auths["/"] as IDictionary;
            ArrayList authz = authMap == null ? new ArrayList() : new ArrayList(authMap.Keys);
            authz.Sort();

            sw.WriteLine("[" + name + ":/]");
            foreach (GroupDto groupDto in project.Groups)
            {
                bool exists = false;
                foreach (string str in authz)
                {
                    if (str.Equals(groupDto.Name))
                    {
                        exists = true;
                        sw.WriteLine("@" + str + "=" + authMap[str].ToString());
                        break;
                    }
                }
                if (!exists)
                {
                    sw.WriteLine("@" + groupDto.Name + "=r");
                }
            }
            sw.WriteLine();

            foreach (FolderDto dto in project.Folders)
            {
                saveProjectAuthz(sw, project, dto, name, "");
            }

            sw.Close();
        }

        private static void saveProjectAuthz(StreamWriter sw, ProjectDto project, FolderDto folder, string root, string parentpath)
        {
            string path = parentpath + "/" + folder.Name;
            IDictionary authMap = project.Auths[path] as IDictionary;
            ArrayList authz = authMap == null ? new ArrayList() : new ArrayList(authMap.Keys);
            authz.Sort();

            //if (authz != null && authz.Count > 0) {
                sw.WriteLine("[" + root + ":" + path + "]");
                foreach (GroupDto groupDto in project.Groups) {
                    bool exists = false;
                    foreach (string str in authz)
                    {
                        if (str.Equals(groupDto.Name))
                        {
                            exists = true;
                            sw.WriteLine("@" + str + "=" + authMap[str].ToString());
                            break;
                        }
                    }
                    if (!exists)
                    {
                        // 判断当前组是否在上级菜单中具有rw权限，如果有那么继承原来的设置
                        string rw = null;
                        string path2 = path;
                        int p = path2.LastIndexOf('/');
                        while (p >= 0)
                        {
                            path2 = path2.Substring(0, p);
                            IDictionary map = project.Auths[path2.Length == 0 ? "/" : path2] as IDictionary;
                            if (map != null)
                            {
                                if (map[groupDto.Name] != null)
                                {
                                    if (map[groupDto.Name].Equals("rw"))
                                    {
                                        rw = "rw";
                                    }
                                    else if (map[groupDto.Name].Equals("r"))
                                    {
                                        if (!"".Equals(path2))
                                        {

                                            rw = "r";
                                        }
                                    }
                                }
                                if (rw != null)
                                {
                                    break;
                                }
                            }
                            p = path2.LastIndexOf("/");
                        }

                        if (rw != null)
                        {
                            //sw.WriteLine("@" + groupDto.Name + "=" + rw);
                        }
                        else
                        {
                            // 检查下层是否有权限，如果有那么得设置权限
                            bool isok = false;
                            foreach (string k in project.Auths.Keys)
                            {
                                if (k.StartsWith(path))
                                {
                                    IDictionary map = project.Auths[k] as IDictionary;
                                    if (map != null)
                                    {
                                        if (map[groupDto.Name] != null)
                                        {
                                            rw = map[groupDto.Name] as string;
                                            isok = true;
                                            break;
                                        }
                                    }
                                }
                            }
                            if (isok)
                            {
                                if ("rw".Equals(rw))
                                {
                                    sw.WriteLine("@" + groupDto.Name + "=" + rw);
                                }
                            }
                            else {
                                sw.WriteLine("@" + groupDto.Name + "=");
                            }
                        }
                    }
                }
                sw.WriteLine();
            //}

            foreach (FolderDto dto in folder.Folders)
            {
                saveProjectAuthz(sw, project, dto, root, path);
            }
        }
    }
}
